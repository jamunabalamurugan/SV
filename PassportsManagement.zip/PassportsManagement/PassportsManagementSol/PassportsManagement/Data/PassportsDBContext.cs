﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using PassportsManagement.Models;

namespace PassportsManagement.Data
{
    public class PassportsDBContext : DbContext
    {
        public PassportsDBContext() : base("name=PM_DB")
        {
        }
        public DbSet<Passport> Passports { get; set; }
    }
}