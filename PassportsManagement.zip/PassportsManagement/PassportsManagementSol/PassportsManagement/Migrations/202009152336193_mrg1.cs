﻿namespace PassportsManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class mrg1 : DbMigration
    {
        public override void Up()
        {
            AlterColumn("dbo.Passports", "PAN", c => c.String(nullable: false));
        }
        
        public override void Down()
        {
            AlterColumn("dbo.Passports", "PAN", c => c.String(nullable: false, maxLength: 10));
        }
    }
}
