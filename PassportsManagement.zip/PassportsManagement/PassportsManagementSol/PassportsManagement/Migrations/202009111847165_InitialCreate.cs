﻿namespace PassportsManagement.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class InitialCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Passports",
                c => new
                    {
                        PassportID = c.Int(nullable: false, identity: true),
                        PassportNumber = c.String(maxLength: 8),
                        PassportHolderName = c.String(nullable: false, maxLength: 50),
                        PAN = c.String(nullable: false, maxLength: 10),
                        Gender = c.Int(nullable: false),
                        IssueType = c.Int(nullable: false),
                        Booklet = c.Int(nullable: false),
                        DOB = c.DateTime(nullable: false),
                        IsTatkal = c.Boolean(nullable: false),
                        PassportFee = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.PassportID);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.Passports");
        }
    }
}
