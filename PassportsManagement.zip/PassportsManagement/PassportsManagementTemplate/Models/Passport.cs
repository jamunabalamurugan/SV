﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PassportsManagement.Models
{
    public enum Gender
    {
        Select, Male, Female, Others
    }
    public enum Booklet
    {
        Select,
        Pages36,
        Pages60
    }
    public enum IssueType
    {
        Select,
        Fresh,
        Renew,
        Duplicate
    }
    public class Passport
    {
        [Key]
        public int PassportID { get; set; }

        //Implement other required propertes with data annotations

        public void GeneratePassportNumber()
        {
            //Format - A1234567
            //Rules -
            //First Character of Holders'Name + 2 digits of Date of Birth's Year 
            //+ 4 digits in PAN + 1 Gender value

            //Implement your code        
        }

        public bool IsMinor()
        {
            //Implement your code
            return false;
        }

        public void CalculateFee()
        {
            int fee = 0;
            //Implement your code
            PassportFee = fee;
        }

        //      The fee for a standard passport in India
        //      -------------------------------------------------------------------------------------------
        //a)	₹1500 – Fresh issuance or reissue of passport(36 pages booklet).
        //b)	₹2000 – Fresh issuance or reissue of passport(60 pages booklet).
        //c)	₹3500 – First time applicant or renewal with expedited('tatkal') service(36 pages booklet).
        //d)	₹4000 – First time applicant or renewal with expedited('tatkal') service(60 pages booklet).
        //e)	₹1000 – Fresh passport issuance for minors(below 18 years of Age).
        //f)	₹3000 – Duplicate passport(36 pages) in lieu of lost, damaged or stolen passport.
        //g)    ₹3500 – Duplicate passport(60 pages) in lieu of lost, damaged or stolen passport.
    }
}
