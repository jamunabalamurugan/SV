﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace PassportsManagement.Data
{
    public class PassportsDBContext 
    {
        //Implement your code
    }
}